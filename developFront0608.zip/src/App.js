import React, { PureComponent } from "react";
import './App.scss';
import { Route, Switch, BrowserRouter } from 'react-router-dom';
import { Spin } from 'antd'
import Layout from './views/layout'
import Login from './views/login'
import store from './redux/store'
class App extends PureComponent {
  constructor(){
    
    super();
    this.state = {
	    loading: false
	  }
  }
  componentDidMount () {
  	// 重点
  	// 监听store中pageLoadingVal值
    store.subscribe(() => {
      let storeState = store.getState()
      this.setState({
        loading: storeState.pageLoadingVal
      })
    })
  }
  render() {
    let {loading}  = this.state
    return (
      <Spin spinning={loading} wrapperClassName="page-loading">
        <div className="App">
          <BrowserRouter>
            <Switch>
              <Route path="/login" exact component={Login} />
              <Route path="/" component={Layout} />
            </Switch>
          </BrowserRouter>
        </div>
      </Spin>
    );
  }
}

export default App;
