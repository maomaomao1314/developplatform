import axios from 'axios';
import { tokenStr, getToken } from './cookie'
import { OPENPAGELOADING, CLOSEPAGELOADING } from '../redux/actions'
import store from '../redux/store'
import { message } from 'antd'
/* 添加一个计数器 */
let needLoadingRequestCount = 0
function showFullScreenLoading() {
  if (needLoadingRequestCount === 0) {
    store.dispatch({ type: OPENPAGELOADING })
  }
  needLoadingRequestCount++
}

function tryHideFullScreenLoading() {
  if (needLoadingRequestCount <= 0) return
  needLoadingRequestCount--
  if (needLoadingRequestCount === 0) {
    store.dispatch({ type: CLOSEPAGELOADING })
  }
}
let instance = axios.create({
  baseURL: '',
  timeout: 5000
})
if (getToken()) {

  instance.defaults.headers.common[tokenStr] = getToken();
}

// 添加请求拦截器
instance.interceptors.request.use(config => {
  showFullScreenLoading()
  return config
}, error => {
  tryHideFullScreenLoading()
  message.error('请求超时')
  return Promise.reject(error)
})
// 添加响应拦截器
instance.interceptors.response.use(response => {
  tryHideFullScreenLoading()
  let { data } = response
  console.log('response', data, data.type)
  if (data && data.code && data.code === 200) {
    return data
  } else if (data && data.size > 0 && data.type == 'application/octet-stream') {
    //二进制流直接返回
    return data
  } else if (data && data.size > 0 && data.type == 'application/json') {
    //message.error('数据配置有问题')
    var reader = new FileReader();
    reader.readAsText(data, 'utf-8');
    reader.onload = function (res) {
    console.log('reader',res.target)
    data = JSON.parse(res.target.result);
    message.error(data.msg || '获取接口数据错误')
    return Promise.reject()
  }
    return Promise.reject()
  } else if (data && data.code && data.code == 500) {
    message.error(data.msg || '获取接口数据错误')
    return Promise.reject()
  } else if (data && data.code && data.code !== 200) {
    message.error(data.msg || '获取接口数据错误')
    // window.location.href = '/login';
    return Promise.reject()
  } else {
    message.error(data.msg || '获取接口数据错误')
    return Promise.reject()
  }
}, error => {
  tryHideFullScreenLoading()
  message.error('服务错误')
  return Promise.reject(error)
})

export default instance