import cookie from 'react-cookies'
export const tokenStr = 'token'
export const usernameStr = 'username'
export function setToken(token){
    // cookie.save(tokenStr, token)
    let inFifteenMinutes = new Date(new Date().getTime() + 1 * 3600 * 1000);//一天
    cookie.save(tokenStr, token,{ expires: inFifteenMinutes }) 
}
export function getToken(){
    return cookie.load(tokenStr)
}
export function removeToken(){
    cookie.remove(tokenStr)
}
export function setUsername(username){
    let inFifteenMinutes = new Date(new Date().getTime() + 1 * 3600 * 1000);//一天
    cookie.save(usernameStr, username,{ expires: inFifteenMinutes })
}
export function getUsername(){
    return cookie.load(usernameStr)
}
export function removeUsername(){
    cookie.remove(usernameStr)
}