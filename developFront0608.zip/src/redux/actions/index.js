export const OPENPAGELOADING = 'OpenPageLoading'
export const CLOSEPAGELOADING = 'ClosePageLoading'
export const SETUSERINFO = 'setUserInfo'