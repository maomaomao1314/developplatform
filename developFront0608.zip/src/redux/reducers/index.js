import { OPENPAGELOADING, CLOSEPAGELOADING, SETUSERINFO } from '../actions'
const initState = {
  pageLoadingVal: false,
  userInfo:null
}
const AppReducer = (state=initState, action) => {
  switch (action.type) {
    case OPENPAGELOADING: {
      return {
        pageLoadingVal: true
      }
    }
    case CLOSEPAGELOADING: {
      return {
        pageLoadingVal: false
      }
    }
    case SETUSERINFO :{
      return {
        userInfo: action.userInfo
      }
    }
    default: {
      return state
    }
  }
}

export default AppReducer