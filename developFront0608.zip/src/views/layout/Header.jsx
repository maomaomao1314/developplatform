import React, { PureComponent } from "react";
import "./style.scss";
import {
  getToken,
  getUsername,
  removeUsername,
  removeToken,
} from "../../utils/cookie";
class Header extends PureComponent {
  componentDidMount() {
    let token = getToken();
    let username = getUsername();
    if (!token || !username) {
      this.loginout();
    }
  }
  loginout = () => {
    removeUsername();
    removeToken();
    this.props.history.push("/login");
  };
  render() {
    let username = getUsername();
    return (
      <div className="header">
        <div>
            <img className="logo-img" src={require('../../images/logo_yellow_white.png').default}  alt="logo" />
            <span className="title">开发平台</span>
        </div>
        <div className="login-box">
          <span className="username">当前用户：{username}</span>
          <span className="loginout" onClick={this.loginout}>
            退出
          </span>
        </div>
      </div>
    );
  }
}
export default Header;
