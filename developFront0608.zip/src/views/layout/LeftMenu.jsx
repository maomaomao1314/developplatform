import React, { PureComponent } from "react";
import { HomeOutlined, QuestionCircleOutlined } from "@ant-design/icons";
import { Menu } from "antd";
import "./style.scss";
class LeftMenu extends PureComponent {
  constructor() {
    super();
    this.state = {
      selectedKeys: "/home",
    };
  }
  componentDidMount() {}
  handleClick = (e) => {
    this.props.history.push(e.key);
    this.setState({
      selectedKeys: e.key,
    });
  };
  render() {
    let selectedKeys = this.props.history.location.pathname;
    return (
      <Menu
        selectedKeys={selectedKeys}
        onClick={this.handleClick}
        style={{ width: "256px", height: "100%", background: "#f5f5f5" }}
        mode="inline"
      >
        <Menu.Item key="/home" path="/home" icon={<HomeOutlined />}>
          首页
        </Menu.Item>
        <Menu.Item
          key="/useFun"
          path="/useFun"
          icon={<QuestionCircleOutlined />}
        >
          使用方法
        </Menu.Item>
      </Menu>
    );
  }
}
export default LeftMenu;
