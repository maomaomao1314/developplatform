import React, { PureComponent } from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import Home from "../home";
import Header from './Header'
import LeftMenu from './LeftMenu'
import UseFun from "../useFun";
import "./style.scss"; 
import { getToken } from '../../utils/cookie'
class Layout extends PureComponent {
  render() {
    let token = getToken()
    return (
      <div className="layout-contianer">
        <Header {...this.props} />
        <div className="main">
          <div className="layout-left">
           <LeftMenu {...this.props} />
          </div>
          <div className="layout-main">
            <Switch>
              <Route exact path="/home" exact component={Home} />
              <Route exact path="/useFun" component={UseFun} />
              {
                token?(<Redirect from="/" to="/home"></Redirect>):(<Redirect from="/" to="/login"></Redirect>)
              }
            </Switch>
          </div>
        </div>
      </div>
    );
  }
}
export default Layout;
