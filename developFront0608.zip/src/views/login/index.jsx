import React, { PureComponent } from "react";
import "antd/dist/antd.css";
import { Form, Input, Button, message } from "antd";
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import "./style.scss";
import {
  setToken,
  setUsername,
} from "../../utils/cookie";
import { SETUSERINFO } from "../../redux/actions";
import store from "../../redux/store";
import Ajax from "../../utils/Ajax";
class Login extends PureComponent {
  formRef = React.createRef();
  onFinish = (params) => {
    Ajax.post("/api/scaffold/login", params).then((res) => {
      let { data } = res;
      console.log(data);
      if (data && data.token && data.user && data.user.userName) {
        setToken(data.token);
        setUsername(data.user.userName);
        store.dispatch({ type: SETUSERINFO, userInfo: data.user });
        this.props.history.push('/')
      } else {
        message.error("返回的登陆信息不正确");
      }
    });
  };

  onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo);
  };
  render() {
    return (
      <div className="login-contianer">
        <div className="logo-box">
          <img  src={require('../../images/logo_yellow_white.png').default} alt="logo" />
        </div>
        <div className="login-bg"></div>
        <div className="login-innerContent">
          <div className="login-header">
            
            <span className="login-title">账号登录</span>
          </div>
          <div className="login-main">
            <Form
              ref={this.formRef}
              onFinish={this.onFinish}
              onFinishFailed={this.onFinishFailed}
              size='large'
              initialValues={{ size: 'large',requiredMarkValue: 'hidden', }}
            >
              <Form.Item
                size="large"
                name="userName"
                rules={[{ required: true, message: "请输入账号!" }]}
              >
                <Input prefix={<UserOutlined className="site-form-item-icon" />} />
              </Form.Item>

              <Form.Item
                size="large"
                name="userPassword"
                rules={[{ required: true, message: "请输入密码!" }]}
              >
                <Input.Password prefix={<LockOutlined className="site-form-item-icon" />} />
              </Form.Item>

              <Form.Item>
                <Button type="primary" htmlType="submit" block size="large">
                  登录
                </Button>
              </Form.Item>
            </Form>
          </div>
        </div>
      </div>
    );
  }
}
export default Login;
