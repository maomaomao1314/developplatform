import React, { PureComponent } from "react";
import "./style.scss";
import './github-markdown-css/github-markdown.css'
import MarkDown from 'react-markdown';
import axios from "axios";
class Home extends PureComponent {
  constructor() {
    super();
    this.state = {
      markdown: "",
    };
  }
  componentDidMount() {
    axios("./useage.md")
      .then((res) => {
        return res.data;
      })
      .then((text) => this.setState({ markdown: text }));
  }
  render() {
    //   console.log(CodeBlock)
    return (
      <div className="userFun-contianer markdown-body">
        <MarkDown children={this.state.markdown}></MarkDown>
      </div>
    );
  }
}
export default Home;
