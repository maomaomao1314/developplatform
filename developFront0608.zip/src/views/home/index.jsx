import React, { PureComponent } from "react";
import { Form, Input, Button, List, message } from "antd";
import SelectDependenceModel from "./SelectDependenceModel";
import {
  CloseOutlined,
  DownloadOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import Ajax from "../../utils/Ajax";
import "./style.scss";
const layout = {
  labelCol: {
    span: 6,
  },
  wrapperCol: {
    span: 18,
  },
};
class Home extends PureComponent {
  constructor() {
    super();
    this.state = {
      showSelectDependenceModel: false,
      selectDependence: [],
    };
  }

  formRef = React.createRef();
  onGroupChange = (e) => {
    const group = e.target.value;
    const artifact = this.formRef.current.getFieldValue("artifact") || "";
    this.formRef.current.setFieldsValue({
      packagePath: group + "." + artifact,
    });
  };
  onArtifactChange = (e) => {
    const artifact = e.target.value;
    const group = this.formRef.current.getFieldValue("group") || "";
    this.formRef.current.setFieldsValue({
      packagePath: group + "." + artifact,
      name: artifact,
    });
  };
  renderForm = () => {
    return (
      <Form {...layout} name="basic" ref={this.formRef}>
        <Form.Item>
          <span style={{ fontWeight: "bold", fontSize: "14px" }}>Project</span>
        </Form.Item>
        <Form.Item
          label="Group"
          name="group"
          rules={[
            {
              required: true,
              message: "Please input your Group!",
            },
          ]}
        >
          <Input onChange={this.onGroupChange} />
        </Form.Item>

        <Form.Item
          label="Artifact"
          name="artifact"
          rules={[
            {
              required: true,
              message: "Please input your Artifact!",
            },
          ]}
        >
          <Input onChange={this.onArtifactChange} />
        </Form.Item>
        {/* <Form.Item
          label="Name"
          name="name"
          rules={[
            {
              required: true,
              message: "Please input your Name!",
            },
          ]}
        >
          <Input />
        </Form.Item> */}
        <Form.Item
          label="Description"
          name="description"
          rules={[
            {
              required: true,
              message: "Please input your Description!",
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Package name"
          name="packagePath"
          rules={[
            {
              required: true,
              message: "Please input your Package name!",
            },
          ]}
        >
          <Input />
        </Form.Item>
      </Form>
    );
  };
  openSelectDependenceModel = () => {
    this.setState({
      showSelectDependenceModel: true,
    });
  };
  closeSelectDependenceModel = () => {
    this.setState({
      showSelectDependenceModel: false,
    });
  };
  saveDependence = (dependence) => {
    console.log("dependence", dependence);
    let selectDependence = this.state.selectDependence;
    let index = selectDependence.findIndex((item) => item.id === dependence.id);
    if (index > -1) {
      message.error("您选择的依赖包已经添加过了");
      return false;
    }
    selectDependence.push(dependence);
    this.setState({
      showSelectDependenceModel: false,
      selectDependence,
    });
  };
  removeDe = (index) => {
    let selectDependence = this.state.selectDependence;
    selectDependence.splice(index, 1);
    this.setState({
      selectDependence: JSON.parse(JSON.stringify(selectDependence)),
    });
  };
  renderDependenceItem = (item, index) => {
    return (
      <List.Item
        actions={[
          <CloseOutlined
            style={{ fontSize: "16px", color: "#ff4d4f" }}
            onClick={this.removeDe.bind(this, index)}
          />,
        ]}
      >
        <div>
          <h5 className="dependence-item">
            <b>{item.dependencyName}</b> <i>{item.dependencyVersion}</i>
          </h5>
          <p className="dependence-des">{item.description}</p>
        </div>
      </List.Item>
    );
  };
  submitDownload = async () => {
    let selectDependence = this.state.selectDependence;
    let values = await this.formRef.current.validateFields();
    values.dependenciesList = selectDependence;
    Ajax.defaults.responseType = "blob";
    let data = await Ajax.post(
      "/api/sfgenDependencies/getGenerateCodeDemoZip",
      values
    );
    if(data) {
      //下载二级制文件
      const blob = new Blob([data]);
      const fileName = "demo.zip";
      if ("download" in document.createElement("a")) {
        // 非IE下载
        const elink = document.createElement("a");
        elink.download = fileName;
        elink.style.display = "none";
        elink.href = URL.createObjectURL(blob);
        document.body.appendChild(elink);
        elink.click();
        URL.revokeObjectURL(elink.href); // 释放URL 对象
        document.body.removeChild(elink);
      } else {
        // IE10+下载
        navigator.msSaveBlob(blob, fileName);
      }
    }
    
  };
  renderList = () => {
    return (
      <div className="dependense">
        <div className="right_header">
          <span style={{ fontWeight: "bold", fontSize: "14px" }}>
            Dependencies
          </span>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={this.openSelectDependenceModel}
          >
            add
          </Button>
        </div>
        <div className="depedengce-list">
          <List
            locale={{ emptyText: "暂无数据" }}
            bordered
            dataSource={this.state.selectDependence}
            renderItem={this.renderDependenceItem}
          />
        </div>
      </div>
    );
  };
  render() {
    return (
      <div className="home-contianer">
        <div className="content flexContent">
          <div className="flex1">{this.renderForm()}</div>
          <div className="flex1">{this.renderList()}</div>
        </div>
        <div className="footer">
          <Button
            type="primary"
            shape="round"
            icon={<DownloadOutlined />}
            size="large"
            onClick={this.submitDownload}
          >
            下载
          </Button>
        </div>
        <SelectDependenceModel
          show={this.state.showSelectDependenceModel}
          close={this.closeSelectDependenceModel}
          save={this.saveDependence}
        />
      </div>
    );
  }
}
export default Home;
