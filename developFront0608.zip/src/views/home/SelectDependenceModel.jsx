import React, { PureComponent } from "react";
import { Modal, Input, List } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import "./style.scss";
import Ajax from "../../utils/Ajax";
class SelectDependenceModel extends PureComponent {
  constructor() {
    super();
    this.state = {
      isModalVisible: false,
      searchValue: "",
      data: [],
    };
  }
  componentDidMount() {
    let params = new URLSearchParams();
    params.append("name", "");
    params.append("pageIndex", "0");
    params.append("pageSize", "1000");
    Ajax.get("/api/sfgenDependencies/getDependenciesList", { params })
      .then((res) => {
        if (res.data && res.data.records) {
          let data = res.data.records;
          this.setState({
            data,
          });
        }
      })
  }
  onChange = (e) => {
    this.setState({
      searchValue: e.target.value,
    });
  };
  render() {
    const { searchValue, data } = this.state;
    let showDate = searchValue && data && data.length >0
      ? data.filter((item) => item.dependencyName && item.dependencyName.toUpperCase().indexOf(searchValue.toUpperCase()) > -1)
      : data;
    return (
      <Modal
        width={800}
        title="选择"
        footer={null}
        visible={this.props.show}
        onCancel={this.props.close}
      >
        <Input
          suffix={<SearchOutlined />}
          onChange={this.onChange}
          placeholder="搜索"
        />
        <List
          locale={{ emptyText: "暂无数据" }}
          style={{ marginTop: "10px", height: "60vh", overflow: "auto" }}
          size="small"
          bordered
          dataSource={showDate}
          renderItem={(item) => (
            <List.Item
              className="select-item"
              onClick={this.props.save.bind(this, item)}
            >
              <div>
                <h5 className="dependence-item">
                  <b>{item.dependencyName}</b> <i>{item.dependencyVersion}</i>
                </h5>
                <p className="dependence-des">{item.description}</p>
              </div>
            </List.Item>
          )}
        />
      </Modal>
    );
  }
}
export default SelectDependenceModel;
