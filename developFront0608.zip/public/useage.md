# xhyj-frame


## 简介

xhyj-frame致力于迅速构建项目雏形。重点突出基础代码生成，将多个项目组在行内还有其他成员行的实践代码进行融合，进一步结合springboot starter模块化功能、公司的maven私库，将第一版代码生成工具进行重构，丰富了各个功能组件，使之更易用，并推出可视化的开发平台门户供公司内部开发同学使用。

### 项目结构

![](D:\工作文档\需求\开发平台\doc\xhyj-framework结构.png)

~~~lua
-- xhyj-frame-base 模块与starter模块都放置于相同gitlab地址,相互独立开
├─xhyj-frame-base  -- 基础模块,parent pom打包
│   ├─xhyj-frame-core  -- 核心包,封装如一些异常处理,切面处理,常量,核心功能等;jar打包
│   └─xhyj-frame-common  -- 通用包,常量以及util放置于此;jar打包
│ ---------------------------------------------------------------------
│ -- 以下模块是提前预置好固定通用功能,再通过脚手架generator选择starter生成最终版,供下载
├─xhyj-frame-module
    ├─xhyj-frame-module-web -- controller层,对接前端以及传参处理;
    ├─xhyj-frame-module-facade --常用的业务对象BO,数据传输对象DTO,rpc接口,供web层调用
    ├─xhyj-frame-module-service --业务代码层,职责单一,供facade调用(facade可聚合多个service)
    └─xhyj-frame-module-dao -- 数据访问层，封装对数据库的增、删、改、查操作

~~~

## 后台开发环境和依赖

- java

- maven 

  > 1. 配置对应的私服仓库
  >
  >    `公司项目仓库地址` 
  >
  >    `行内传统区仓库地址`
  >
  > 2. 配置自己本地setting.xml文件，详见CF地址 

- jdk8 

- mysql

- redis

## 功能列表

~~~lua

~~~

| 功能 | 简介 |
| ---- | ---- |
|      |      |

## 使用文档

> 详见使用手册：

## 开发规范

> 通过脚手架平台生成的项目名称为XXX的项目结构如下

### 代码目录规范

~~~lua
├─xxx -- 所有项目的父pom
    ├─xxx-web -- controller层,对接前端以及传参处理;
	│   └─src
	│	   └─main
	│		  ├─java
	│		  │   └─com.xhyj.xxx
	│		  │		    ├─CodeGenerator.java -- 业务代码模板生成器
	│		  │   		└─controller
	│		  │   			├─user -- 用户相关
	│		  │   			├─order -- 订单相关
	│		  │   	   	   ...
	│		  └─resources
	│		      ├─ -- 配置文件目录
    ├─xxx-facade --常用的业务对象BO,数据传输对象DTO,rpc接口,供web层调用
	│   └─src
	│	   └─main
	│		  └─java
	│		     └─com.xhyj.xxx
	│		     		├─dto -- 不同的业务按照不同的目录放置
	│		     		│	├─user -- 用户相关
	│		     		│	├─order -- 订单相关
	│		    		│	...
	│		     		├─facade
	│		     		│	├─user -- 用户相关
	│		     		│	│	└─impl -- 具体用户实现类存放
	│		     		│	│	├─ IUserFacade.java -- 接口声明类
	│		     		│	│  ... -- 其余用户相关的facade接口声明
    │		     		│	├─order -- 订单相关
	│		     		│  ...	└─impl -- 具体订单实现类存放
	│		     		│	    ... -- 其余订单相关的facade接口声明
	│		     		└─vo
	│		     		  ├─user -- 用户相关
	│		     		  ├─order -- 订单相关
	│		    		 ...
	│	
    ├─xxx-service --业务代码层,职责单一,供facade调用(facade可聚合多个service)
	│   └─src
	│	   └─main
	│		  └─java
	│		     └─com.xhyj.xxx.service
	│		     		├─user -- 用户业务
	│		     		│	└─impl -- 具体用户实现类存放
	│		     		│	├─ IUserService.java -- 接口声明类
	│		     		│  ... -- 其余用户相关的service接口声明
    │		     		├─order -- 订单业务
	│		     		...	└─impl -- 具体订单实现类存放
	│		     			    ... -- 其余订单相关的service接口声明
	│		  
    └─xxx-dao -- 数据访问层，封装对数据库的增、删、改、查操作
	    └─src
		   └─main
			  └─java
			  │   └─com.xhyj.xxx.dao
              │         ├─user -- 用户dao
			  │   		│	└─po -- 用户相关po实体
			  │   		│	├─ UserMapper.java -- Mapper接口
			  │   		│  ... -- 其余用户相关的mapper接口
    		  │   		├─order -- 订单业务
			  │   		...	└─po -- 订单相关po实体
			  │   			    ... -- 其余订单相关的mapper接口
			  │	
			  └─resources
						└─mapper
							├─user -- 用户对应的mapper.xml
							└─order -- 订单对应的mapper.xml
~~~

### 命名规范

* 包路径命名规范
* 类命名规范
* 

### 代码规范

### 代码提交规范



## 贡献人员(排名不分先后)

* 曹道华(caodaohua@jsxhyj.cn)
* 齐少华()
* 王翔(wangxiang@jsxhyj.cn)
* 杨潇风()